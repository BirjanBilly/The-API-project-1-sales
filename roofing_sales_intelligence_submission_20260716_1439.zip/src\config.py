from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

from dotenv import load_dotenv

ROOT_DIR = Path(__file__).resolve().parents[1]
load_dotenv(ROOT_DIR / ".env")


def _int_env(name: str, default: int) -> int:
    raw = os.getenv(name)
    if raw is None:
        return default
    try:
        return int(raw)
    except ValueError as exc:
        raise ValueError(f"Environment variable {name} must be an integer.") from exc


@dataclass(frozen=True)
class Settings:
    root_dir: Path = ROOT_DIR
    database_url: str = os.getenv("DATABASE_URL", "sqlite:///roofing_leads.db")
    openai_api_key: str | None = os.getenv("OPENAI_API_KEY")
    perplexity_api_key: str | None = os.getenv("PERPLEXITY_API_KEY")
    openai_model: str = os.getenv("OPENAI_MODEL", "gpt-5.6")
    research_ttl_days: int = _int_env("RESEARCH_TTL_DAYS", 30)
    perplexity_max_results: int = _int_env("PERPLEXITY_MAX_RESULTS", 5)
    request_timeout_seconds: int = _int_env("REQUEST_TIMEOUT_SECONDS", 45)


settings = Settings()
