from __future__ import annotations

from pathlib import Path

import pandas as pd

INPUT_PATH = Path("data/gaf_contractors_10013_corrected.csv")
OUTPUT_PATH = Path("data/gaf_contractors_10013_verified.csv")


PATCHES: dict[str, dict[str, object]] = {
    "https://www.gaf.com/en-us/roofing-contractors/residential/usa/ny/new-hyde-park/preferred-exterior-corp-1004859": {
        "company_name": "Preferred Exterior Corp",
        "address": "1998 Hillside Ave, New Hyde Park, NY 11040",
        "city": "New Hyde Park",
        "state": "NY",
        "postal_code": "11040",
        "phone": "(516) 354-7252",
        "company_website": "https://www.preferredexterior.com/",
        "certification_level": "Master Elite",
        "award": "President's Club",
        "rating": 5.0,
        "review_count": 49,
    },
    "https://www.gaf.com/en-us/roofing-contractors/residential/usa/nj/garfield/jersey-roofing-llc-1141159": {
        "company_name": "Jersey Roofing LLC",
        "address": "411 River Dr, Garfield, NJ 07026",
        "city": "Garfield",
        "state": "NJ",
        "postal_code": "07026",
        "phone": "(201) 982-2718",
        "company_website": "https://jerseyroofingllc.com/",
        "certification_level": "Master Elite",
        "award": "President's Club",
        "rating": 5.0,
        "review_count": 468,
    },
    "https://www.gaf.com/en-us/roofing-contractors/residential/usa/nj/florham-park/american-home-contractors-inc-1005149": {
        "company_name": "American Home Contractors Inc",
        "address": "124 Crescent Rd, Florham Park, NJ 07932",
        "city": "Florham Park",
        "state": "NJ",
        "postal_code": "07932",
        "phone": "(908) 771-0123",
        "company_website": "https://njahc.com/",
        "certification_level": "Master Elite",
        "award": "President's Club",
        "rating": 5.0,
        "review_count": 267,
    },
    "https://www.gaf.com/en-us/roofing-contractors/residential/usa/nj/elmwood-park/donnys-home-improvement-1139561": {
        "company_name": "Donny's Home Improvement",
        "address": "30 16th Ave, Elmwood Park, NJ 07407",
        "city": "Elmwood Park",
        "state": "NJ",
        "postal_code": "07407",
        "phone": "(973) 333-6364",
        "company_website": "https://www.donnysroofing.com/",
        "certification_level": "Master Elite",
        "award": "President's Club",
        "rating": 5.0,
        "review_count": 120,
    },
    "https://www.gaf.com/en-us/roofing-contractors/residential/usa/ny/valley-stream/brothers-aluminum-home-improvements-corp-1100696": {
        "company_name": "Brothers Aluminum Home Improvements Corp",
        "address": "20 W Lincoln Ave, Valley Stream, NY 11580",
        "city": "Valley Stream",
        "state": "NY",
        "postal_code": "11580",
        "phone": "(516) 872-0947",
        "company_website": None,
        "certification_level": "Master Elite",
        "award": "President's Club",
        "rating": 4.9,
        "review_count": 395,
    },
    "https://www.gaf.com/en-us/roofing-contractors/residential/usa/nj/montville/blue-nail-exteriors-1113999": {
        "company_name": "Blue Nail Exteriors",
        "address": "193 Changebridge Rd, Montville, NJ 07045",
        "city": "Montville",
        "state": "NJ",
        "postal_code": "07045",
        "phone": "(973) 937-8876",
        "company_website": "https://bluenailnj.com/",
        "certification_level": "Master Elite",
        "award": "President's Club",
        "rating": 4.9,
        "review_count": 358,
    },
    "https://www.gaf.com/en-us/roofing-contractors/residential/usa/ny/mineola/rebuild-america-inc-1002371": {
        "company_name": "Rebuild America Inc",
        "address": "39 Windsor Ave, Mineola, NY 11501",
        "city": "Mineola",
        "state": "NY",
        "postal_code": "11501",
        "phone": "(516) 535-9293",
        "company_website": "https://www.rebuildamericany.com/",
        "certification_level": "Master Elite",
        "award": "President's Club",
        "rating": 4.9,
        "review_count": 92,
    },
    "https://www.gaf.com/en-us/roofing-contractors/residential/usa/ny/bronx/rh-renovation-llc-1143942": {
        "company_name": "RH Renovation LLC",
        "address": "1951 Hone Ave, Bronx, NY 10461",
        "city": "Bronx",
        "state": "NY",
        "postal_code": "10461",
        "phone": "(646) 818-4305",
        "company_website": "https://rhrenovationnyc.com/",
        "certification_level": "Master Elite",
        "award": None,
        "rating": 5.0,
        "review_count": 330,
    },
    "https://www.gaf.com/en-us/roofing-contractors/residential/usa/ny/bronx/ak-gatsios-inc-1101267": {
        "company_name": "AK Gatsios Inc",
        "address": "1162 Ellsworth Ave, Bronx, NY 10465",
        "city": "Bronx",
        "state": "NY",
        "postal_code": "10465",
        "phone": "(646) 302-5175",
        "company_website": "https://akgatsiosinc.com/",
        "certification_level": "Master Elite",
        "award": None,
        "rating": 5.0,
        "review_count": 325,
    },
}


def main() -> None:
    if not INPUT_PATH.exists():
        raise FileNotFoundError(INPUT_PATH)

    dataframe = pd.read_csv(
        INPUT_PATH,
        dtype={
            "postal_code": "string",
            "source_zip": "string",
        },
    )

    required_columns = {
        "company_name",
        "gaf_profile_url",
        "address",
        "city",
        "state",
        "postal_code",
        "phone",
        "company_website",
        "certification_level",
        "award",
        "rating",
        "review_count",
        "source_type",
    }

    missing_columns = required_columns.difference(dataframe.columns)

    if missing_columns:
        raise ValueError(
            f"CSV is missing required columns: {sorted(missing_columns)}"
        )

    patched_count = 0

    for profile_url, values in PATCHES.items():
        matching_rows = dataframe.index[
            dataframe["gaf_profile_url"].eq(profile_url)
        ].tolist()

        if len(matching_rows) != 1:
            raise ValueError(
                f"Expected one row for {profile_url}, "
                f"but found {len(matching_rows)}."
            )

        row_index = matching_rows[0]

        for column_name, value in values.items():
            dataframe.at[row_index, column_name] = (
                pd.NA if value is None else value
            )

        dataframe.at[
            row_index,
            "source_type",
        ] = "gaf_profile_manually_verified"

        patched_count += 1

    # President's Club is an award held by qualifying Master Elite contractors,
    # rather than a separate certification level.
    president_mask = (
        dataframe["award"]
        .fillna("")
        .astype(str)
        .str.contains("President", case=False)
    )

    dataframe.loc[
        president_mask,
        "certification_level",
    ] = "Master Elite"

    dataframe.loc[
        president_mask,
        "award",
    ] = "President's Club"

    # Preserve leading zeroes in New Jersey ZIP codes.
    dataframe["postal_code"] = (
        dataframe["postal_code"]
        .astype("string")
        .str.replace(r"\.0$", "", regex=True)
        .str.zfill(5)
    )

    dataframe.to_csv(
        OUTPUT_PATH,
        index=False,
        encoding="utf-8-sig",
    )

    print(f"Patched rows: {patched_count}")
    print(f"Saved verified CSV to: {OUTPUT_PATH}")
    print(
        "Unique company names:",
        dataframe["company_name"].nunique(),
    )


if __name__ == "__main__":
    main()
