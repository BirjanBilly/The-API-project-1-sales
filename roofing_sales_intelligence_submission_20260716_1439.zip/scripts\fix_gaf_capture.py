from __future__ import annotations

import argparse
import csv
import json
import re
import time
from collections.abc import Iterator
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

from playwright.sync_api import Page, sync_playwright

GENERIC_NAMES = {
    "request a quote",
    "request an estimate",
    "get a quote",
    "get an estimate",
    "contact us",
    "call now",
    "view profile",
    "website",
    "directions",
    "find a contractor",
    "find a residential roofing contractor near you",
    "top residential roofers near me",
    "residential roofers near me",
    "gaf",
}

PHONE_RE = re.compile(r"(?:\+1[\s.-]?)?\(?\d{3}\)?[\s.-]\d{3}[\s.-]\d{4}")
CERTIFICATIONS = (
    "President's Club",
    "Master Elite",
    "Certified Plus",
    "Certified",
)
SOCIAL_OR_UTILITY_HOSTS = (
    "gaf.com",
    "google.com",
    "goo.gl",
    "facebook.com",
    "instagram.com",
    "linkedin.com",
    "youtube.com",
    "x.com",
    "twitter.com",
    "maps.apple.com",
)


def clean_text(value: Any) -> str:
    if value is None:
        return ""
    return " ".join(str(value).split()).strip()


def is_valid_company_name(value: str) -> bool:
    name = clean_text(value)
    lowered = name.lower().strip(" :-|\u2013\u2014")
    if len(name) < 3 or len(name) > 255:
        return False
    if lowered in GENERIC_NAMES:
        return False
    if lowered.startswith("request a ") or lowered.startswith("get a "):
        return False
    if "roofers near me" in lowered or "find a contractor" in lowered:
        return False
    return True


def walk_json(value: Any) -> Iterator[dict[str, Any]]:
    if isinstance(value, dict):
        yield value
        for child in value.values():
            yield from walk_json(child)
    elif isinstance(value, list):
        for child in value:
            yield from walk_json(child)


def jsonld_objects(page: Page) -> list[dict[str, Any]]:
    objects: list[dict[str, Any]] = []
    for raw in page.locator('script[type="application/ld+json"]').all_text_contents():
        raw = raw.strip()
        if not raw:
            continue
        try:
            parsed = json.loads(raw)
        except json.JSONDecodeError:
            continue
        objects.extend(walk_json(parsed))
    return objects


def type_values(obj: dict[str, Any]) -> set[str]:
    raw = obj.get("@type")
    if isinstance(raw, str):
        return {raw.lower()}
    if isinstance(raw, list):
        return {str(item).lower() for item in raw}
    return set()


def pick_business_jsonld(objects: list[dict[str, Any]]) -> dict[str, Any] | None:
    preferred_types = {
        "roofingcontractor",
        "homeandconstructionbusiness",
        "localbusiness",
        "professionalservice",
        "organization",
    }
    for obj in objects:
        if type_values(obj) & preferred_types and is_valid_company_name(clean_text(obj.get("name"))):
            return obj
    for obj in objects:
        if is_valid_company_name(clean_text(obj.get("name"))):
            return obj
    return None


def extract_address(obj: dict[str, Any] | None) -> tuple[str, str, str, str]:
    if not obj:
        return "", "", "", ""
    address = obj.get("address")
    if isinstance(address, str):
        return clean_text(address), "", "", ""
    if not isinstance(address, dict):
        return "", "", "", ""
    street = clean_text(address.get("streetAddress"))
    city = clean_text(address.get("addressLocality"))
    state = clean_text(address.get("addressRegion"))
    postal = clean_text(address.get("postalCode"))
    full = ", ".join(part for part in (street, city, state, postal) if part)
    return full, city, state, postal


def first_valid_text(page: Page, selectors: tuple[str, ...]) -> str:
    for selector in selectors:
        locator = page.locator(selector)
        count = min(locator.count(), 8)
        for index in range(count):
            try:
                text = clean_text(locator.nth(index).inner_text(timeout=1500))
            except Exception:
                continue
            if is_valid_company_name(text):
                return text
    return ""


def title_fallback(page: Page) -> str:
    title = clean_text(page.title())
    for separator in (" | ", " - ", " \u2013 ", " \u2014 "):
        if separator in title:
            candidate = title.split(separator, 1)[0].strip()
            if is_valid_company_name(candidate):
                return candidate
    return title if is_valid_company_name(title) else ""


def extract_external_website(page: Page) -> str:
    anchors = page.locator('a[href^="http"]')
    preferred: list[str] = []
    fallback: list[str] = []
    for index in range(min(anchors.count(), 250)):
        anchor = anchors.nth(index)
        href = clean_text(anchor.get_attribute("href"))
        if not href:
            continue
        host = (urlparse(href).hostname or "").lower()
        if not host or any(blocked in host for blocked in SOCIAL_OR_UTILITY_HOSTS):
            continue
        text = clean_text(anchor.inner_text()).lower()
        if "website" in text or "visit site" in text or "company site" in text:
            preferred.append(href)
        else:
            fallback.append(href)
    return (preferred or fallback or [""])[0]


def extract_profile(page: Page, row: dict[str, str]) -> dict[str, str]:
    body_text = clean_text(page.locator("body").inner_text(timeout=10000))
    objects = jsonld_objects(page)
    business = pick_business_jsonld(objects)

    name = clean_text(business.get("name")) if business else ""
    if not is_valid_company_name(name):
        name = first_valid_text(
            page,
            (
                "main h1",
                "article h1",
                "h1",
                '[data-testid*="contractor"] h1',
                '[class*="contractor"] h1',
                '[class*="profile"] h1',
            ),
        )
    if not is_valid_company_name(name):
        name = title_fallback(page)

    address, city, state, postal = extract_address(business)
    telephone = clean_text(business.get("telephone")) if business else ""
    if not telephone:
        match = PHONE_RE.search(body_text)
        telephone = match.group(0) if match else ""

    website = clean_text(business.get("url")) if business else ""
    if website and "gaf.com" in (urlparse(website).hostname or "").lower():
        website = ""
    if not website:
        website = extract_external_website(page)

    certification = ""
    body_lower = body_text.lower()
    for label in CERTIFICATIONS:
        if label.lower() in body_lower:
            certification = label
            break

    award = "President's Club" if "president's club" in body_lower else ""

    rating = ""
    review_count = ""
    if business:
        aggregate = business.get("aggregateRating")
        if isinstance(aggregate, dict):
            rating = clean_text(aggregate.get("ratingValue"))
            review_count = clean_text(aggregate.get("reviewCount") or aggregate.get("ratingCount"))

    result = dict(row)
    result.update(
        {
            "company_name": name if is_valid_company_name(name) else "REVIEW REQUIRED",
            "address": address or clean_text(row.get("address")),
            "city": city or clean_text(row.get("city")),
            "state": state or clean_text(row.get("state")) or "NY",
            "postal_code": postal or clean_text(row.get("postal_code")),
            "phone": telephone or clean_text(row.get("phone")),
            "company_website": website or clean_text(row.get("company_website")),
            "certification_level": certification or clean_text(row.get("certification_level")),
            "award": award or clean_text(row.get("award")),
            "rating": rating or clean_text(row.get("rating")),
            "review_count": review_count or clean_text(row.get("review_count")),
            "source_type": "gaf_profile_enriched_capture",
        }
    )
    return result


def write_rows(path: Path, fieldnames: list[str], rows: list[dict[str, str]]) -> None:
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", default="data/gaf_contractors_10013_capture.csv")
    parser.add_argument("--output", default="data/gaf_contractors_10013_corrected.csv")
    parser.add_argument("--headless", action="store_true")
    args = parser.parse_args()

    input_path = Path(args.input)
    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    with input_path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        fieldnames = list(reader.fieldnames or [])
        rows = list(reader)

    if "company_name" not in fieldnames or "gaf_profile_url" not in fieldnames:
        raise SystemExit("Input CSV is missing company_name or gaf_profile_url.")

    corrected: list[dict[str, str]] = []
    with sync_playwright() as playwright:
        browser = playwright.chromium.launch(headless=args.headless)
        context = browser.new_context(viewport={"width": 1440, "height": 1000})
        page = context.new_page()

        for index, row in enumerate(rows, start=1):
            url = clean_text(row.get("gaf_profile_url"))
            if not url:
                print(f"[{index}/{len(rows)}] Missing profile URL; manual review required.")
                corrected.append(dict(row))
                continue

            print(f"[{index}/{len(rows)}] Visiting {url}")
            try:
                page.goto(url, wait_until="domcontentloaded", timeout=60000)
                page.wait_for_timeout(1200)
                enriched = extract_profile(page, row)
                print(f"    -> {enriched['company_name']}")
                corrected.append(enriched)
            except Exception as exc:
                failed = dict(row)
                failed["company_name"] = "REVIEW REQUIRED"
                corrected.append(failed)
                print(f"    ERROR: {type(exc).__name__}: {exc}")

            write_rows(output_path, fieldnames, corrected)
            time.sleep(0.6)

        context.close()
        browser.close()

    valid = sum(1 for row in corrected if is_valid_company_name(row.get("company_name", "")))
    print(f"Saved {len(corrected)} rows to {output_path}.")
    print(f"Automatically resolved company names: {valid}/{len(corrected)}")
    print("Open the corrected CSV and manually verify every row before importing it.")


if __name__ == "__main__":
    main()
