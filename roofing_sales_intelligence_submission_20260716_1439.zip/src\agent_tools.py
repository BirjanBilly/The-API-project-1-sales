from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.orm import selectinload

from src.database import init_db, session_scope
from src.ingest import import_csv
from src.models import Company
from src.pipeline import enrich_company
from src.scoring import compute_score


def ingest_gaf_seed(csv_path: str) -> dict:
    """Import a manually verified or approved GAF seed CSV."""
    init_db()
    return import_csv(csv_path).model_dump()


def build_company_intelligence(company_id: int, force_research: bool = False) -> dict:
    """Research one company, generate a grounded brief, and persist it."""
    init_db()
    return enrich_company(company_id, force_research=force_research)


def retrieve_lead_brief(company_id: int) -> dict:
    """Return a stored lead brief suitable for an agent or API response."""
    init_db()
    with session_scope() as session:
        company = session.scalar(
            select(Company)
            .where(Company.id == company_id)
            .options(
                selectinload(Company.evidence),
                selectinload(Company.contacts),
                selectinload(Company.insight),
            )
        )
        if company is None:
            raise ValueError(f"Company {company_id} does not exist.")
        score = compute_score(company)
        return {
            "company_id": company.id,
            "company_name": company.company_name,
            "score": score.as_dict(),
            "insight": None
            if company.insight is None
            else {
                "summary": company.insight.company_summary,
                "why_now": company.insight.why_now,
                "pain_points": company.insight.pain_points,
                "recommended_products": company.insight.recommended_products,
                "outreach_angle": company.insight.outreach_angle,
                "next_best_action": company.insight.next_best_action,
                "confidence": company.insight.confidence_score,
                "source_urls": company.insight.source_urls,
            },
            "decision_makers": [
                {
                    "name": contact.full_name,
                    "title": contact.job_title,
                    "source_url": contact.source_url,
                    "confidence": contact.confidence,
                }
                for contact in company.contacts
            ],
        }
