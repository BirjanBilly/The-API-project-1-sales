﻿from __future__ import annotations

from datetime import datetime, timezone

from sqlalchemy import JSON, DateTime, Float, ForeignKey, Integer, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from src.database import Base


def utcnow() -> datetime:
    return datetime.now(timezone.utc).replace(tzinfo=None)


class Company(Base):
    __tablename__ = "companies"
    __table_args__ = (
        UniqueConstraint("normalized_name", "postal_code", name="uq_company_name_postal"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    company_name: Mapped[str] = mapped_column(String(255), index=True)
    normalized_name: Mapped[str] = mapped_column(String(255), index=True)
    gaf_profile_url: Mapped[str | None] = mapped_column(String(1500), unique=True, nullable=True)
    company_website: Mapped[str | None] = mapped_column(String(1500), nullable=True)
    address: Mapped[str | None] = mapped_column(String(500), nullable=True)
    city: Mapped[str | None] = mapped_column(String(100), index=True, nullable=True)
    state: Mapped[str | None] = mapped_column(String(20), index=True, nullable=True)
    postal_code: Mapped[str | None] = mapped_column(String(20), index=True, nullable=True)
    phone: Mapped[str | None] = mapped_column(String(100), nullable=True)
    distance_miles: Mapped[float | None] = mapped_column(Float, nullable=True)
    certification_level: Mapped[str | None] = mapped_column(String(100), nullable=True)
    award: Mapped[str | None] = mapped_column(String(200), nullable=True)
    rating: Mapped[float | None] = mapped_column(Float, nullable=True)
    review_count: Mapped[int | None] = mapped_column(Integer, nullable=True)
    source_zip: Mapped[str] = mapped_column(String(20), index=True)
    source_type: Mapped[str] = mapped_column(String(50), default="gaf_manual_seed")
    captured_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, onupdate=utcnow)

    evidence: Mapped[list[Evidence]] = relationship(
        back_populates="company",
        cascade="all, delete-orphan",
        order_by="Evidence.retrieved_at.desc()",
    )
    contacts: Mapped[list[Contact]] = relationship(
        back_populates="company",
        cascade="all, delete-orphan",
    )
    insight: Mapped[Insight | None] = relationship(
        back_populates="company",
        cascade="all, delete-orphan",
        uselist=False,
    )
    reviews: Mapped[list[LeadReview]] = relationship(
        back_populates="company",
        cascade="all, delete-orphan",
    )


class Evidence(Base):
    __tablename__ = "evidence"
    __table_args__ = (
        UniqueConstraint("company_id", "source_url", name="uq_company_evidence_url"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    company_id: Mapped[int] = mapped_column(ForeignKey("companies.id"), index=True)
    source_url: Mapped[str] = mapped_column(String(1500))
    source_title: Mapped[str | None] = mapped_column(String(500), nullable=True)
    snippet: Mapped[str | None] = mapped_column(Text, nullable=True)
    published_at: Mapped[str | None] = mapped_column(String(100), nullable=True)
    signal_type: Mapped[str | None] = mapped_column(String(100), nullable=True)
    query: Mapped[str | None] = mapped_column(Text, nullable=True)
    retrieved_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, index=True)

    company: Mapped[Company] = relationship(back_populates="evidence")


class Contact(Base):
    __tablename__ = "contacts"
    __table_args__ = (
        UniqueConstraint("company_id", "full_name", "job_title", name="uq_company_contact"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    company_id: Mapped[int] = mapped_column(ForeignKey("companies.id"), index=True)
    full_name: Mapped[str] = mapped_column(String(255))
    job_title: Mapped[str] = mapped_column(String(255))
    source_url: Mapped[str] = mapped_column(String(1500))
    public_business_email: Mapped[str | None] = mapped_column(String(320), nullable=True)
    confidence: Mapped[float] = mapped_column(Float)
    verified_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)

    company: Mapped[Company] = relationship(back_populates="contacts")


class Insight(Base):
    __tablename__ = "insights"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    company_id: Mapped[int] = mapped_column(ForeignKey("companies.id"), unique=True, index=True)
    company_summary: Mapped[str] = mapped_column(Text)
    why_now: Mapped[str] = mapped_column(Text)
    pain_points: Mapped[list[str]] = mapped_column(JSON, default=list)
    recommended_products: Mapped[list[str]] = mapped_column(JSON, default=list)
    outreach_angle: Mapped[str] = mapped_column(Text)
    next_best_action: Mapped[str] = mapped_column(Text)
    confidence_score: Mapped[float] = mapped_column(Float)
    source_urls: Mapped[list[str]] = mapped_column(JSON, default=list)
    evidence_hash: Mapped[str] = mapped_column(String(64), index=True)
    model_name: Mapped[str] = mapped_column(String(100))
    generated_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)

    company: Mapped[Company] = relationship(back_populates="insight")


class PipelineRun(Base):
    __tablename__ = "pipeline_runs"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    started_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    finished_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    status: Mapped[str] = mapped_column(String(30), default="running")
    companies_requested: Mapped[int] = mapped_column(Integer, default=0)
    companies_processed: Mapped[int] = mapped_column(Integer, default=0)
    companies_failed: Mapped[int] = mapped_column(Integer, default=0)
    errors: Mapped[list[dict]] = mapped_column(JSON, default=list)


class LeadReview(Base):
    __tablename__ = "lead_reviews"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    company_id: Mapped[int] = mapped_column(ForeignKey("companies.id"), index=True)
    status: Mapped[str] = mapped_column(String(30), default="new")
    assigned_to: Mapped[str | None] = mapped_column(String(255), nullable=True)
    notes: Mapped[str | None] = mapped_column(Text, nullable=True)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, onupdate=utcnow)

    company: Mapped[Company] = relationship(back_populates="reviews")

