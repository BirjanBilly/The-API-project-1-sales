﻿"""Optional browser-assisted collection of public GAF result links.

This script deliberately requires the user to perform the ZIP search manually. It does not
bypass authentication, CAPTCHA, rate limits, or other access controls. Review GAF's terms and
obtain permission before using automated collection beyond a small case-study prototype.
"""
from __future__ import annotations

import argparse
import csv
import re
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urljoin

from playwright.sync_api import sync_playwright

GAF_URL = "https://www.gaf.com/en-us/roofing-contractors/residential?distance=25"
PROFILE_FRAGMENT = "/roofing-contractors/residential/usa/"
PHONE_RE = re.compile(r"(?:\+1[\s.-]?)?\(?\d{3}\)?[\s.-]\d{3}[\s.-]\d{4}")
CERTIFICATIONS = ("President's Club", "Master Elite", "Certified Plus", "Certified")


def clean_company_name(text: str) -> str:
    lines = [line.strip() for line in text.splitlines() if line.strip()]
    generic = {"view profile", "website", "call", "get a quote", "directions"}
    for line in lines:
        if line.lower() not in generic and len(line) > 2:
            return line[:255]
    return "Review required"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--zip", default="10013")
    parser.add_argument("--output", default="data/gaf_contractors_10013_capture.csv")
    args = parser.parse_args()

    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    with sync_playwright() as playwright:
        browser = playwright.chromium.launch(headless=False)
        page = browser.new_page(viewport={"width": 1440, "height": 1000})
        page.goto(GAF_URL, wait_until="domcontentloaded")
        print("\nIn the opened browser:")
        print("1. Select Residential.")
        print("2. Clear any existing location such as SL1.")
        print(f"3. Type {args.zip}, select the New York autocomplete result, and run the search.")
        print("4. Expand the distance if needed and wait until contractor cards appear.")
        input("Press Enter here only after the result cards are visible...")
        page.wait_for_timeout(2000)

        anchors = page.locator(f'a[href*="{PROFILE_FRAGMENT}"]')
        rows_by_url: dict[str, dict] = {}
        for index in range(anchors.count()):
            anchor = anchors.nth(index)
            href = anchor.get_attribute("href") or ""
            full_url = urljoin(page.url, href)
            # General city/location pages are often shallower than contractor profile pages.
            suffix = full_url.split(PROFILE_FRAGMENT, 1)[-1]
            if suffix.count("/") < 2:
                continue

            text = (anchor.inner_text() or "").strip()
            try:
                container = anchor.locator("xpath=ancestor::*[self::article or self::li or self::div][1]")
                card_text = (container.inner_text() or text).strip()
            except Exception:
                card_text = text

            certification = next(
                (label for label in CERTIFICATIONS if label.lower() in card_text.lower()),
                None,
            )
            phone_match = PHONE_RE.search(card_text)
            rows_by_url[full_url] = {
                "company_name": clean_company_name(text or card_text),
                "gaf_profile_url": full_url,
                "address": "",
                "city": "",
                "state": "NY",
                "postal_code": "",
                "phone": phone_match.group(0) if phone_match else "",
                "company_website": "",
                "distance_miles": "",
                "certification_level": certification or "",
                "award": "",
                "rating": "",
                "review_count": "",
                "source_zip": args.zip,
                "captured_at": datetime.now(timezone.utc).date().isoformat(),
                "source_type": "gaf_browser_assisted_capture",
            }

        browser.close()

    fieldnames = [
        "company_name",
        "gaf_profile_url",
        "address",
        "city",
        "state",
        "postal_code",
        "phone",
        "company_website",
        "distance_miles",
        "certification_level",
        "award",
        "rating",
        "review_count",
        "source_zip",
        "captured_at",
        "source_type",
    ]
    with output_path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows_by_url.values())

    print(f"Saved {len(rows_by_url)} candidate records to {output_path}.")
    print("Open the CSV and manually verify every row before importing it.")


if __name__ == "__main__":
    main()

