from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.orm import selectinload

from src.database import init_db, session_scope
from src.models import Company, PipelineRun

INVALID_NAMES = {
    "",
    "residential",
    "commercial",
    "review required",
    "request a quote",
}


def main() -> None:
    init_db()

    with session_scope() as session:
        companies = list(
            session.scalars(
                select(Company)
                .options(
                    selectinload(Company.evidence),
                    selectinload(Company.contacts),
                    selectinload(Company.insight),
                )
                .order_by(Company.id)
            ).all()
        )

        runs = list(
            session.scalars(
                select(PipelineRun)
                .order_by(PipelineRun.id)
            ).all()
        )

        enriched = [
            company
            for company in companies
            if company.insight is not None
        ]

        invalid = [
            company.company_name
            for company in companies
            if company.company_name.strip().lower()
            in INVALID_NAMES
        ]

        missing_distance = [
            company.company_name
            for company in companies
            if company.distance_miles is None
        ]

        evidence_count = sum(
            len(company.evidence)
            for company in companies
        )

        contact_count = sum(
            len(company.contacts)
            for company in companies
        )

        print("FINAL READINESS REPORT")
        print("=" * 60)
        print(f"Companies: {len(companies)}")
        print(f"Unique company names: {len(set(c.company_name for c in companies))}")
        print(f"Enriched companies: {len(enriched)}")
        print(f"Evidence records: {evidence_count}")
        print(f"Contact candidates: {contact_count}")
        print(f"Pipeline runs: {len(runs)}")
        print(f"Invalid company names: {len(invalid)}")
        print(f"Companies missing exact distance: {len(missing_distance)}")

        print()
        print("PIPELINE RUNS")

        for run in runs:
            print(
                f"Run {run.id}: "
                f"status={run.status}, "
                f"requested={run.companies_requested}, "
                f"processed={run.companies_processed}, "
                f"failed={run.companies_failed}"
            )

        print()
        print("ENRICHED LEADS")

        for company in enriched:
            print(
                f"{company.id:>2} | "
                f"{company.company_name:<45} | "
                f"sources={len(company.evidence):>2} | "
                f"contacts={len(company.contacts):>2} | "
                f"confidence={company.insight.confidence_score}"
            )

        if invalid:
            print()
            print("INVALID NAMES")
            for name in invalid:
                print(name)

        if missing_distance:
            print()
            print("MISSING EXACT DISTANCES")
            for name in missing_distance:
                print(name)


if __name__ == "__main__":
    main()
