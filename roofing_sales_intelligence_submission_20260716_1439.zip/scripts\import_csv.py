from __future__ import annotations

import argparse

from src.database import init_db
from src.ingest import import_csv


def main() -> None:
    parser = argparse.ArgumentParser(description="Import GAF contractor CSV data.")
    parser.add_argument("csv_path")
    args = parser.parse_args()
    init_db()
    summary = import_csv(args.csv_path)
    print(summary.model_dump_json(indent=2))


if __name__ == "__main__":
    main()
