from __future__ import annotations

import argparse
import sys
from pathlib import Path

import pandas as pd

INVALID_EXACT_NAMES = {
    "",
    "residential",
    "commercial",
    "review required",
    "request a quote",
    "request a free quote",
    "request an estimate",
    "get a quote",
    "get an estimate",
    "find a contractor",
    "visit website",
}


def normalise_text(value: object) -> str:
    if pd.isna(value):
        return ""

    return " ".join(str(value).strip().lower().split())


def is_invalid_company_name(value: object) -> bool:
    text = normalise_text(value)

    if text in INVALID_EXACT_NAMES:
        return True

    invalid_prefixes = (
        "request a ",
        "get a ",
        "find a ",
        "review required",
    )

    return text.startswith(invalid_prefixes)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("csv_path")
    arguments = parser.parse_args()

    csv_path = Path(arguments.csv_path)

    if not csv_path.exists():
        print(f"File does not exist: {csv_path}")
        return 2

    dataframe = pd.read_csv(
        csv_path,
        dtype={
            "postal_code": "string",
            "source_zip": "string",
        },
    )

    invalid_name_mask = dataframe["company_name"].apply(
        is_invalid_company_name
    )

    duplicate_url_mask = (
        dataframe["gaf_profile_url"]
        .fillna("")
        .duplicated(keep=False)
    )

    duplicate_name_mask = (
        dataframe["company_name"]
        .fillna("")
        .str.strip()
        .str.lower()
        .duplicated(keep=False)
    )

    suspicious_website_mask = (
        dataframe["company_website"]
        .fillna("")
        .str.contains(
            r"streetbond\.com|gaf\.com/en-us/roofing-materials",
            case=False,
            regex=True,
        )
    )

    print("NUMBER OF ROWS")
    print(len(dataframe))

    print()
    print("QUALITY SUMMARY")
    print(
        "missing_company_names:",
        int(dataframe["company_name"].isna().sum()),
    )
    print(
        "generic_or_invalid_company_names:",
        int(invalid_name_mask.sum()),
    )
    print(
        "unique_company_names:",
        int(dataframe["company_name"].nunique()),
    )
    print(
        "missing_profile_urls:",
        int(dataframe["gaf_profile_url"].isna().sum()),
    )
    print(
        "duplicate_profile_urls:",
        int(duplicate_url_mask.sum()),
    )
    print(
        "duplicate_company_name_rows:",
        int(duplicate_name_mask.sum()),
    )
    print(
        "suspicious_company_websites:",
        int(suspicious_website_mask.sum()),
    )

    problem_mask = (
        invalid_name_mask
        | duplicate_url_mask
        | duplicate_name_mask
        | suspicious_website_mask
    )

    print()
    print("ROWS REQUIRING REVIEW")

    if not problem_mask.any():
        print("None")
        return 0

    columns = [
        "company_name",
        "gaf_profile_url",
        "phone",
        "certification_level",
        "award",
        "company_website",
    ]

    print(
        dataframe.loc[problem_mask, columns].to_string(index=False)
    )

    return 1


if __name__ == "__main__":
    sys.exit(main())
