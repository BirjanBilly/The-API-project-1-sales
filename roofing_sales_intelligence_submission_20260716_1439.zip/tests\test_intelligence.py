from src.intelligence import sanitize_insight
from src.schemas import DecisionMakerCandidate, SalesInsight


def test_unsupported_urls_and_contacts_are_removed():
    insight = SalesInsight(
        company_summary="A sufficiently long company summary for testing.",
        why_now="A sufficiently long current signal explanation for testing.",
        pain_points=[],
        recommended_products=["architectural shingles"],
        outreach_angle="A sufficiently long outreach angle for testing.",
        next_best_action="Review the evidence.",
        decision_makers=[
            DecisionMakerCandidate(
                name="Supported Person",
                title="Owner",
                source_url="https://allowed.test/about",
                confidence=0.9,
            ),
            DecisionMakerCandidate(
                name="Unsupported Person",
                title="President",
                source_url="https://invented.test/profile",
                confidence=0.9,
            ),
        ],
        confidence_score=0.7,
        source_urls=["https://allowed.test/about", "https://invented.test/profile"],
    )
    result = sanitize_insight(insight, {"https://allowed.test/about"})
    assert result.source_urls == ["https://allowed.test/about"]
    assert [item.name for item in result.decision_makers] == ["Supported Person"]
