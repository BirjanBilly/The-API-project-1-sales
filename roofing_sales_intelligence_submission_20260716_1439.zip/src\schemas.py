from __future__ import annotations

from pydantic import BaseModel, Field


class DecisionMakerCandidate(BaseModel):
    name: str = Field(min_length=2, max_length=200)
    title: str = Field(min_length=2, max_length=200)
    source_url: str = Field(min_length=8, max_length=1500)
    public_business_email: str | None = None
    confidence: float = Field(ge=0.0, le=1.0)


class SalesInsight(BaseModel):
    company_summary: str = Field(min_length=10)
    why_now: str = Field(min_length=10)
    pain_points: list[str] = Field(default_factory=list, max_length=6)
    recommended_products: list[str] = Field(default_factory=list, max_length=6)
    outreach_angle: str = Field(min_length=10)
    next_best_action: str = Field(min_length=5)
    decision_makers: list[DecisionMakerCandidate] = Field(default_factory=list, max_length=5)
    confidence_score: float = Field(ge=0.0, le=1.0)
    source_urls: list[str] = Field(default_factory=list)


class ImportSummary(BaseModel):
    processed: int = 0
    inserted: int = 0
    updated: int = 0
    skipped: int = 0
    errors: list[str] = Field(default_factory=list)
