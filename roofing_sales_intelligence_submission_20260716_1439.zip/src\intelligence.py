from __future__ import annotations

import json
from collections.abc import Iterable

from src.config import settings
from src.models import Company, Evidence
from src.schemas import DecisionMakerCandidate, SalesInsight


class MissingOpenAIKeyError(RuntimeError):
    pass


SYSTEM_PROMPT = """
You are a cautious B2B sales-intelligence analyst supporting a roofing-material distributor.
Use only the company record and public evidence supplied by the application.

Rules:
1. Never invent a person, title, email, project, revenue, headcount, product SKU, customer, or event.
2. A decision-maker may be included only if a supplied source explicitly identifies both the person and role.
3. If no supported decision-maker exists, return an empty decision_makers list.
4. Do not guess personal email addresses. Include an email only if the evidence explicitly publishes it as a business contact.
5. Recommended products must be broad roofing-distributor categories, not fabricated SKUs.
6. Every source URL returned must appear in the supplied evidence.
7. Distinguish evidence from inference and lower confidence when evidence is sparse or old.
8. Keep the language concise and useful for account planning.
""".strip()


def _company_payload(company: Company) -> dict:
    return {
        "company_name": company.company_name,
        "gaf_profile_url": company.gaf_profile_url,
        "company_website": company.company_website,
        "address": company.address,
        "city": company.city,
        "state": company.state,
        "postal_code": company.postal_code,
        "phone": company.phone,
        "distance_miles": company.distance_miles,
        "certification_level": company.certification_level,
        "award": company.award,
        "rating": company.rating,
        "review_count": company.review_count,
    }


def _evidence_payload(evidence: Iterable[Evidence]) -> list[dict]:
    return [
        {
            "title": item.source_title,
            "url": item.source_url,
            "snippet": item.snippet,
            "published_at": item.published_at,
            "signal_type": item.signal_type,
        }
        for item in evidence
    ]


def sanitize_insight(insight: SalesInsight, allowed_urls: set[str]) -> SalesInsight:
    """Remove any citation or contact that is not grounded in supplied evidence."""
    source_urls = [url for url in insight.source_urls if url in allowed_urls]
    contacts: list[DecisionMakerCandidate] = []
    for contact in insight.decision_makers:
        if contact.source_url in allowed_urls:
            contacts.append(contact)
    return insight.model_copy(
        update={
            "source_urls": list(dict.fromkeys(source_urls)),
            "decision_makers": contacts,
        }
    )


def generate_sales_insight(company: Company, evidence: list[Evidence]) -> SalesInsight:
    if not settings.openai_api_key:
        raise MissingOpenAIKeyError(
            "OPENAI_API_KEY is missing. Add a newly rotated key to .env."
        )

    from openai import OpenAI

    client = OpenAI(api_key=settings.openai_api_key)
    payload = {
        "company": _company_payload(company),
        "evidence": _evidence_payload(evidence),
    }
    response = client.responses.parse(
        model=settings.openai_model,
        input=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {
                "role": "user",
                "content": (
                    "Create an evidence-grounded account-planning brief from this JSON:\n"
                    + json.dumps(payload, indent=2, default=str)
                ),
            },
        ],
        text_format=SalesInsight,
    )
    insight = response.output_parsed
    if insight is None:
        raise ValueError("OpenAI returned no parsed structured output.")
    allowed_urls = {item.source_url for item in evidence}
    return sanitize_insight(insight, allowed_urls)


def deterministic_fallback_insight(company: Company, evidence: list[Evidence]) -> SalesInsight:
    """Create a low-confidence brief when an API key is unavailable during a demo."""
    certification = company.certification_level or company.award or "GAF-listed contractor"
    sources = [item.source_url for item in evidence[:3]]
    return SalesInsight(
        company_summary=(
            f"{company.company_name} is recorded as a {certification} serving the "
            f"{company.city or 'local'} market. Additional public research should be reviewed "
            "before making company-specific claims."
        ),
        why_now=(
            "The company appears in the current GAF contractor dataset and is within the selected "
            "sales territory, making it suitable for representative review."
        ),
        pain_points=[
            "Public evidence is insufficient to infer a verified company-specific pain point."
        ],
        recommended_products=[
            "architectural shingles",
            "underlayment and leak barriers",
            "ventilation and roof-system accessories",
        ],
        outreach_angle=(
            "Open with the contractor's GAF position and local market coverage, then ask which roof-system "
            "components, availability constraints, or warranty requirements matter most this season."
        ),
        next_best_action="Verify the public business contact and review the supporting sources before outreach.",
        decision_makers=[],
        confidence_score=0.2,
        source_urls=sources,
    )
