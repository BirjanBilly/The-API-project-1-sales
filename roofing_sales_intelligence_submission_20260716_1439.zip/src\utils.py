from __future__ import annotations

import hashlib
import json
import re
import time
from collections.abc import Callable
from typing import TypeVar

T = TypeVar("T")


def normalized_company_name(value: str) -> str:
    """Normalise a company name for duplicate detection."""
    cleaned = re.sub(r"[^a-z0-9]+", " ", value.lower()).strip()
    suffixes = {"llc", "inc", "corp", "corporation", "ltd", "company", "co"}
    words = [word for word in cleaned.split() if word not in suffixes]
    return " ".join(words)


def stable_json_hash(value: object) -> str:
    serialised = json.dumps(value, sort_keys=True, default=str, separators=(",", ":"))
    return hashlib.sha256(serialised.encode("utf-8")).hexdigest()


def retry_call(
    function: Callable[[], T],
    *,
    attempts: int = 3,
    initial_delay_seconds: float = 1.0,
    retryable: tuple[type[BaseException], ...] = (Exception,),
) -> T:
    """Run a function with bounded exponential backoff."""
    delay = initial_delay_seconds
    last_error: BaseException | None = None
    for attempt in range(1, attempts + 1):
        try:
            return function()
        except retryable as exc:
            last_error = exc
            if attempt == attempts:
                break
            time.sleep(delay)
            delay *= 2
    assert last_error is not None
    raise last_error
