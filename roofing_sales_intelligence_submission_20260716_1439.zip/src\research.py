from __future__ import annotations

from dataclasses import dataclass
from urllib.parse import urlparse

import httpx

from src.config import settings
from src.models import Company
from src.utils import retry_call


class MissingPerplexityKeyError(RuntimeError):
    pass


class RetryableSearchError(RuntimeError):
    pass


@dataclass(frozen=True)
class SearchEvidence:
    title: str
    url: str
    snippet: str
    published_at: str | None
    signal_type: str
    query: str


def classify_signal(text: str) -> str:
    lowered = text.lower()
    rules = {
        "hiring": ("hiring", "careers", "job opening", "join our team"),
        "project": ("project", "completed", "installed", "roof replacement"),
        "expansion": ("expansion", "new location", "opened", "growing"),
        "award": ("award", "winner", "certified", "master elite", "president's club"),
        "leadership": ("owner", "president", "founder", "leadership", "team"),
        "service": ("residential", "commercial", "repair", "installation", "service area"),
    }
    for label, keywords in rules.items():
        if any(keyword in lowered for keyword in keywords):
            return label
    return "general"


class PerplexitySearchClient:
    endpoint = "https://api.perplexity.ai/search"

    def __init__(self, api_key: str | None = None) -> None:
        self.api_key = api_key or settings.perplexity_api_key
        if not self.api_key:
            raise MissingPerplexityKeyError(
                "PERPLEXITY_API_KEY is missing. Add a newly rotated key to .env."
            )

    def search(self, query: str, *, max_results: int | None = None) -> list[SearchEvidence]:
        max_results = max_results or settings.perplexity_max_results

        def make_request() -> httpx.Response:
            with httpx.Client(timeout=settings.request_timeout_seconds) as client:
                response = client.post(
                    self.endpoint,
                    headers={
                        "Authorization": f"Bearer {self.api_key}",
                        "Content-Type": "application/json",
                    },
                    json={
                        "query": query,
                        "country": "US",
                        "max_results": max_results,
                        "search_context_size": "high",
                        "search_language_filter": ["en"],
                        "search_domain_filter": ["-pinterest.com", "-reddit.com", "-quora.com"],
                    },
                )
                if response.status_code == 429 or response.status_code >= 500:
                    raise RetryableSearchError(
                        f"Retryable Perplexity response: {response.status_code}"
                    )
                response.raise_for_status()
                return response

        response = retry_call(
            make_request,
            attempts=3,
            retryable=(httpx.TimeoutException, httpx.NetworkError, RetryableSearchError),
        )
        payload = response.json()
        results = payload.get("results", [])
        evidence: list[SearchEvidence] = []
        for result in results:
            url = str(result.get("url") or "").strip()
            if not url.startswith(("http://", "https://")):
                continue
            title = str(result.get("title") or "").strip()
            snippet = str(result.get("snippet") or "").strip()
            evidence.append(
                SearchEvidence(
                    title=title,
                    url=url,
                    snippet=snippet,
                    published_at=result.get("date") or result.get("last_updated"),
                    signal_type=classify_signal(f"{title} {snippet}"),
                    query=query,
                )
            )
        return evidence


def _website_domain(url: str | None) -> str | None:
    if not url:
        return None
    domain = urlparse(url).netloc.lower()
    return domain.removeprefix("www.") or None


def research_company(company: Company) -> list[SearchEvidence]:
    client = PerplexitySearchClient()
    place = ", ".join(part for part in (company.city, company.state) if part) or "New York"
    queries = [
        f'"{company.company_name}" roofing {place} owner president founder leadership',
        f'"{company.company_name}" roofing {place} recent projects awards hiring expansion services',
    ]
    domain = _website_domain(company.company_website)
    if domain:
        queries.append(f"site:{domain} about team leadership services projects")

    by_url: dict[str, SearchEvidence] = {}
    for query in queries:
        for item in client.search(query):
            by_url[item.url] = item
    return list(by_url.values())
