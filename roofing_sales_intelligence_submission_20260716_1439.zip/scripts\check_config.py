from __future__ import annotations

from src.config import settings


def main() -> None:
    print(f"openai_key_loaded: {bool(settings.openai_api_key)}")
    print(f"perplexity_key_loaded: {bool(settings.perplexity_api_key)}")
    print(f"openai_model: {settings.openai_model}")
    print(f"database_url: {settings.database_url}")
    print(f"research_ttl_days: {settings.research_ttl_days}")


if __name__ == "__main__":
    main()
