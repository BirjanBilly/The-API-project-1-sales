from __future__ import annotations

import argparse

from src.database import init_db
from src.pipeline import run_pipeline


def main() -> None:
    parser = argparse.ArgumentParser(description="Run the roofing lead enrichment pipeline.")
    parser.add_argument("--company-id", action="append", type=int, dest="company_ids")
    parser.add_argument("--limit", type=int, default=None)
    parser.add_argument("--force-research", action="store_true")
    parser.add_argument("--no-fallback", action="store_true")
    args = parser.parse_args()

    init_db()
    result = run_pipeline(
        args.company_ids,
        limit=args.limit,
        force_research=args.force_research,
        allow_offline_fallback=not args.no_fallback,
    )
    print(result)


if __name__ == "__main__":
    main()
