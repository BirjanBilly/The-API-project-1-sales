﻿from __future__ import annotations

from datetime import datetime, timedelta, timezone

from sqlalchemy import delete, select
from sqlalchemy.orm import selectinload

from src.config import settings
from src.database import session_scope
from src.intelligence import (
    MissingOpenAIKeyError,
    deterministic_fallback_insight,
    generate_sales_insight,
)
from src.models import Company, Contact, Evidence, Insight, PipelineRun
from src.research import MissingPerplexityKeyError, research_company
from src.utils import stable_json_hash


def _load_company(company_id: int) -> Company:
    with session_scope() as session:
        company = session.scalar(
            select(Company)
            .where(Company.id == company_id)
            .options(
                selectinload(Company.evidence),
                selectinload(Company.contacts),
                selectinload(Company.insight),
            )
        )
        if company is None:
            raise ValueError(f"Company {company_id} does not exist.")
        session.expunge(company)
        return company


def _evidence_is_fresh(company: Company) -> bool:
    if not company.evidence:
        return False
    newest = max(item.retrieved_at for item in company.evidence)
    return newest >= datetime.now(timezone.utc).replace(tzinfo=None) - timedelta(days=settings.research_ttl_days)


def _save_research(company_id: int, research_items: list) -> None:
    with session_scope() as session:
        existing_urls = set(
            session.scalars(
                select(Evidence.source_url).where(Evidence.company_id == company_id)
            ).all()
        )
        for item in research_items:
            if item.url in existing_urls:
                evidence = session.scalar(
                    select(Evidence).where(
                        Evidence.company_id == company_id,
                        Evidence.source_url == item.url,
                    )
                )
                if evidence:
                    evidence.source_title = item.title
                    evidence.snippet = item.snippet
                    evidence.published_at = item.published_at
                    evidence.signal_type = item.signal_type
                    evidence.query = item.query
                    evidence.retrieved_at = datetime.now(timezone.utc).replace(tzinfo=None)
                continue
            session.add(
                Evidence(
                    company_id=company_id,
                    source_url=item.url,
                    source_title=item.title,
                    snippet=item.snippet,
                    published_at=item.published_at,
                    signal_type=item.signal_type,
                    query=item.query,
                )
            )


def _evidence_hash(company: Company) -> str:
    payload = [
        {
            "url": item.source_url,
            "title": item.source_title,
            "snippet": item.snippet,
            "published_at": item.published_at,
        }
        for item in sorted(company.evidence, key=lambda item: item.source_url)
    ]
    return stable_json_hash(payload)


def _save_insight(company_id: int, insight_data, evidence_hash: str, model_name: str) -> None:
    with session_scope() as session:
        insight = session.scalar(select(Insight).where(Insight.company_id == company_id))
        if insight is None:
            insight = Insight(
                company_id=company_id,
                company_summary=insight_data.company_summary,
                why_now=insight_data.why_now,
                outreach_angle=insight_data.outreach_angle,
                next_best_action=insight_data.next_best_action,
                confidence_score=insight_data.confidence_score,
                evidence_hash=evidence_hash,
                model_name=model_name,
            )
            session.add(insight)

        insight.company_summary = insight_data.company_summary
        insight.why_now = insight_data.why_now
        insight.pain_points = insight_data.pain_points
        insight.recommended_products = insight_data.recommended_products
        insight.outreach_angle = insight_data.outreach_angle
        insight.next_best_action = insight_data.next_best_action
        insight.confidence_score = insight_data.confidence_score
        insight.source_urls = insight_data.source_urls
        insight.evidence_hash = evidence_hash
        insight.model_name = model_name
        insight.generated_at = datetime.now(timezone.utc).replace(tzinfo=None)

        session.execute(delete(Contact).where(Contact.company_id == company_id))
        for candidate in insight_data.decision_makers:
            session.add(
                Contact(
                    company_id=company_id,
                    full_name=candidate.name,
                    job_title=candidate.title,
                    source_url=candidate.source_url,
                    public_business_email=candidate.public_business_email,
                    confidence=candidate.confidence,
                )
            )


def enrich_company(
    company_id: int,
    *,
    force_research: bool = False,
    allow_offline_fallback: bool = True,
) -> dict:
    company = _load_company(company_id)

    research_status = "cached"
    if force_research or not _evidence_is_fresh(company):
        try:
            items = research_company(company)
            _save_research(company_id, items)
            research_status = f"retrieved {len(items)} sources"
        except MissingPerplexityKeyError:
            if not allow_offline_fallback:
                raise
            research_status = "skipped: no Perplexity key"

    company = _load_company(company_id)
    evidence_hash = _evidence_hash(company)

    if company.insight and company.insight.evidence_hash == evidence_hash and not force_research:
        return {
            "company_id": company_id,
            "status": "unchanged",
            "research": research_status,
            "message": "Evidence was unchanged, so the existing insight was reused.",
        }

    try:
        if not company.evidence and allow_offline_fallback:
            insight_data = deterministic_fallback_insight(company, company.evidence)
            model_name = "deterministic-fallback-no-evidence"
        else:
            insight_data = generate_sales_insight(company, company.evidence)
            model_name = settings.openai_model
    except MissingOpenAIKeyError:
        if not allow_offline_fallback:
            raise
        insight_data = deterministic_fallback_insight(company, company.evidence)
        model_name = "deterministic-fallback"

    _save_insight(company_id, insight_data, evidence_hash, model_name)
    return {
        "company_id": company_id,
        "status": "completed",
        "research": research_status,
        "message": f"Insight stored using {model_name}.",
    }


def run_pipeline(
    company_ids: list[int] | None = None,
    *,
    limit: int | None = None,
    force_research: bool = False,
    allow_offline_fallback: bool = True,
) -> dict:
    with session_scope() as session:
        if company_ids is None:
            query = select(Company.id).order_by(Company.id)
            if limit:
                query = query.limit(limit)
            company_ids = list(session.scalars(query).all())
        run = PipelineRun(companies_requested=len(company_ids))
        session.add(run)
        session.flush()
        run_id = run.id

    processed = 0
    failed = 0
    errors: list[dict] = []
    results: list[dict] = []
    for company_id in company_ids:
        try:
            result = enrich_company(
                company_id,
                force_research=force_research,
                allow_offline_fallback=allow_offline_fallback,
            )
            results.append(result)
            processed += 1
        except Exception as exc:  # Continue processing other companies.
            failed += 1
            errors.append({"company_id": company_id, "error": str(exc)})

    with session_scope() as session:
        run = session.get(PipelineRun, run_id)
        assert run is not None
        run.finished_at = datetime.now(timezone.utc).replace(tzinfo=None)
        run.companies_processed = processed
        run.companies_failed = failed
        run.errors = errors
        run.status = "completed" if failed == 0 else "partial" if processed else "failed"

    return {
        "run_id": run_id,
        "status": "completed" if failed == 0 else "partial" if processed else "failed",
        "processed": processed,
        "failed": failed,
        "errors": errors,
        "results": results,
    }

