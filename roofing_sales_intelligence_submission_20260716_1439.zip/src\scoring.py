﻿from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import datetime, timedelta, timezone

from src.models import Company


@dataclass(frozen=True)
class ScoreBreakdown:
    certification: int
    proximity: int
    reputation: int
    completeness: int
    recent_activity: int
    decision_maker: int
    product_fit: int

    @property
    def total(self) -> int:
        return sum(asdict(self).values())

    def as_dict(self) -> dict[str, int]:
        result = asdict(self)
        result["total"] = self.total
        return result


def _certification_score(company: Company) -> int:
    text = " ".join(
        value.lower()
        for value in (company.certification_level, company.award)
        if value
    )
    if "president" in text:
        return 25
    if "master elite" in text:
        return 20
    if "certified plus" in text:
        return 15
    if "certified" in text:
        return 10
    return 0


def _proximity_score(distance: float | None) -> int:
    if distance is None:
        return 0
    if distance <= 5:
        return 15
    if distance <= 10:
        return 12
    if distance <= 25:
        return 8
    if distance <= 50:
        return 4
    return 0


def _reputation_score(rating: float | None, reviews: int | None) -> int:
    if rating is None or reviews is None:
        return 0
    score = 6 if rating >= 4.7 else 4 if rating >= 4.3 else 2 if rating >= 4.0 else 0
    score += 4 if reviews >= 100 else 2 if reviews >= 25 else 0
    return min(score, 10)


def _completeness_score(company: Company) -> int:
    values = (
        company.company_website,
        company.phone,
        company.address,
        company.gaf_profile_url,
    )
    return round(sum(bool(value) for value in values) / len(values) * 10)


def _recent_activity_score(company: Company) -> int:
    cutoff = datetime.now(timezone.utc).replace(tzinfo=None) - timedelta(days=365)
    strong_signals = {"project", "expansion", "hiring", "award"}
    score = 0
    for item in company.evidence:
        if item.signal_type in strong_signals:
            score += 4
        if item.published_at:
            try:
                published = datetime.fromisoformat(item.published_at.replace("Z", "+00:00")).replace(tzinfo=None)
                if published >= cutoff:
                    score += 2
            except ValueError:
                pass
    if company.evidence:
        score += 1
    return min(score, 15)


def compute_score(company: Company) -> ScoreBreakdown:
    insight = company.insight
    product_fit = 0
    if insight and insight.recommended_products:
        product_fit = min(10, round(insight.confidence_score * 10))
    decision_maker = 0
    if company.contacts:
        decision_maker = min(15, round(max(contact.confidence for contact in company.contacts) * 15))

    return ScoreBreakdown(
        certification=_certification_score(company),
        proximity=_proximity_score(company.distance_miles),
        reputation=_reputation_score(company.rating, company.review_count),
        completeness=_completeness_score(company),
        recent_activity=_recent_activity_score(company),
        decision_maker=decision_maker,
        product_fit=product_fit,
    )

