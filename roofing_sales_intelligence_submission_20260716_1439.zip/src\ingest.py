﻿from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path

import pandas as pd
from sqlalchemy import select
from sqlalchemy.orm import Session

from src.database import session_scope
from src.models import Company
from src.schemas import ImportSummary
from src.utils import normalized_company_name

REQUIRED_COLUMNS = {"company_name", "source_zip"}
OPTIONAL_COLUMNS = {
    "gaf_profile_url",
    "address",
    "city",
    "state",
    "postal_code",
    "phone",
    "company_website",
    "distance_miles",
    "certification_level",
    "award",
    "rating",
    "review_count",
    "captured_at",
    "source_type",
}


def _clean_text(value: object) -> str | None:
    if value is None or pd.isna(value):
        return None
    text = str(value).strip()
    return text or None


def _clean_float(value: object) -> float | None:
    if value is None or pd.isna(value) or str(value).strip() == "":
        return None
    return float(value)


def _clean_int(value: object) -> int | None:
    if value is None or pd.isna(value) or str(value).strip() == "":
        return None
    return int(float(value))


def _clean_datetime(value: object) -> datetime:
    if value is None or pd.isna(value) or str(value).strip() == "":
        return datetime.now(timezone.utc).replace(tzinfo=None)
    return pd.to_datetime(value, utc=False).to_pydatetime().replace(tzinfo=None)


def load_csv(path: str | Path) -> pd.DataFrame:
    dataframe = pd.read_csv(path, dtype={"postal_code": "string", "source_zip": "string"})
    missing = REQUIRED_COLUMNS - set(dataframe.columns)
    if missing:
        raise ValueError(f"CSV is missing required columns: {sorted(missing)}")
    for column in OPTIONAL_COLUMNS:
        if column not in dataframe.columns:
            dataframe[column] = None
    return dataframe


def upsert_dataframe(dataframe: pd.DataFrame, session: Session) -> ImportSummary:
    summary = ImportSummary()

    for row_number, row in dataframe.iterrows():
        summary.processed += 1
        try:
            company_name = _clean_text(row.get("company_name"))
            source_zip = _clean_text(row.get("source_zip"))
            if not company_name or not source_zip:
                summary.skipped += 1
                summary.errors.append(f"Row {row_number + 2}: company_name and source_zip are required.")
                continue

            normalized_name = normalized_company_name(company_name)
            gaf_profile_url = _clean_text(row.get("gaf_profile_url"))
            postal_code = _clean_text(row.get("postal_code"))

            company = None
            if gaf_profile_url:
                company = session.scalar(
                    select(Company).where(Company.gaf_profile_url == gaf_profile_url)
                )
            if company is None:
                company = session.scalar(
                    select(Company).where(
                        Company.normalized_name == normalized_name,
                        Company.postal_code == postal_code,
                    )
                )

            inserted = company is None
            if inserted:
                company = Company(
                    company_name=company_name,
                    normalized_name=normalized_name,
                    source_zip=source_zip,
                )
                session.add(company)

            company.company_name = company_name
            company.normalized_name = normalized_name
            company.gaf_profile_url = gaf_profile_url
            company.company_website = _clean_text(row.get("company_website"))
            company.address = _clean_text(row.get("address"))
            company.city = _clean_text(row.get("city"))
            company.state = _clean_text(row.get("state"))
            company.postal_code = postal_code
            company.phone = _clean_text(row.get("phone"))
            company.distance_miles = _clean_float(row.get("distance_miles"))
            company.certification_level = _clean_text(row.get("certification_level"))
            company.award = _clean_text(row.get("award"))
            company.rating = _clean_float(row.get("rating"))
            company.review_count = _clean_int(row.get("review_count"))
            company.source_zip = source_zip
            company.source_type = _clean_text(row.get("source_type")) or "gaf_manual_seed"
            company.captured_at = _clean_datetime(row.get("captured_at"))

            if inserted:
                summary.inserted += 1
            else:
                summary.updated += 1
        except (TypeError, ValueError) as exc:
            summary.skipped += 1
            summary.errors.append(f"Row {row_number + 2}: {exc}")

    session.flush()
    return summary


def import_csv(path: str | Path) -> ImportSummary:
    dataframe = load_csv(path)
    with session_scope() as session:
        return upsert_dataframe(dataframe, session)

