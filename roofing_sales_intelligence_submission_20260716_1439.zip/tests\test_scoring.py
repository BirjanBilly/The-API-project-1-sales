from src.models import Company, Contact, Insight
from src.scoring import compute_score


def company(certification: str, distance: float) -> Company:
    return Company(
        company_name="Example",
        normalized_name="example",
        source_zip="10013",
        postal_code="10001",
        certification_level=certification,
        distance_miles=distance,
        rating=4.8,
        review_count=120,
        company_website="https://example.test",
        phone="212-555-0100",
        address="1 Test Street",
        gaf_profile_url="https://example.test/gaf",
    )


def test_higher_certification_and_proximity_scores_more():
    strong = company("Master Elite", 4)
    weak = company("Certified", 40)
    assert compute_score(strong).total > compute_score(weak).total


def test_score_is_bounded():
    item = company("President's Club", 1)
    item.contacts = [
        Contact(
            company_id=1,
            full_name="Public Person",
            job_title="Owner",
            source_url="https://example.test/about",
            confidence=1.0,
        )
    ]
    item.insight = Insight(
        company_id=1,
        company_summary="A sufficiently long summary for the test.",
        why_now="A sufficiently long why-now statement for the test.",
        pain_points=[],
        recommended_products=["shingles"],
        outreach_angle="A sufficiently long outreach angle for the test.",
        next_best_action="Review the public source.",
        confidence_score=1.0,
        source_urls=[],
        evidence_hash="0" * 64,
        model_name="test",
    )
    assert 0 <= compute_score(item).total <= 100
