from __future__ import annotations

from sqlalchemy import select

from src.database import init_db, session_scope
from src.models import Company


def main() -> None:
    init_db()

    with session_scope() as session:
        companies = list(
            session.scalars(
                select(Company).order_by(Company.id)
            ).all()
        )

        print(f"company_count: {len(companies)}")

        for company in companies:
            certification = (
                company.certification_level
                or "Unspecified"
            )

            print(
                f"{company.id:>2} | "
                f"{company.company_name:<45} | "
                f"{certification:<15} | "
                f"{company.phone or 'no phone'}"
            )


if __name__ == "__main__":
    main()
