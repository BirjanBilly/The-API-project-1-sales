from __future__ import annotations

import pandas as pd
from sqlalchemy import select

from src.ingest import upsert_dataframe
from src.models import Company


def sample_dataframe() -> pd.DataFrame:
    return pd.DataFrame(
        [
            {
                "company_name": "Example Roofing LLC",
                "gaf_profile_url": "https://example.test/gaf/example",
                "postal_code": "10001",
                "source_zip": "10013",
                "rating": "4.8",
                "review_count": "42",
            }
        ]
    )


def test_import_is_idempotent(session):
    first = upsert_dataframe(sample_dataframe(), session)
    session.commit()
    second = upsert_dataframe(sample_dataframe(), session)
    session.commit()

    companies = list(session.scalars(select(Company)).all())
    assert first.inserted == 1
    assert second.updated == 1
    assert len(companies) == 1
    assert companies[0].postal_code == "10001"


def test_blank_rating_becomes_none(session):
    dataframe = sample_dataframe()
    dataframe.loc[0, "rating"] = ""
    upsert_dataframe(dataframe, session)
    session.commit()
    company = session.scalar(select(Company))
    assert company is not None
    assert company.rating is None
